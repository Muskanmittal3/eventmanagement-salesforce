import { LightningElement, api } from 'lwc';
import registerAttendee from '@salesforce/apex/EventController.registerAttendee';

export default class AttendeeForm extends LightningElement {
    @api eventId;
    name = '';
    email = '';
    phone = '';

    handleNameChange(event) {
        this.name = event.target.value;
    }

    handleEmailChange(event) {
        this.email = event.target.value;
    }

    handlePhoneChange(event) {
        this.phone = event.target.value;
    }

    handleSubmit() {
        registerAttendee({
            eventId: this.eventId,
            name: this.name,
            email: this.email,
            phone: this.phone
        }).then(() => {
            alert('Registered successfully!');
        }).catch(error => {
            console.error(error);
            alert('Registration failed.' + error.body.message);
        });
    }
}
