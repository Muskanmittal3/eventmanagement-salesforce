import { LightningElement, wire, track } from 'lwc';
import getUpcomingEvents from '@salesforce/apex/EventController.getUpcomingEvents';

export default class EventList extends LightningElement {
    @track events = [];
    @track isModalOpen = false;
    @track selectedEventId = null;

    @wire(getUpcomingEvents)
    wiredEvents({ error, data }) {
        if (data) {
            this.events = data;
        } else if (error) {
            console.error(error);
        }
    }

    handleRegisterClick(event) {
        this.selectedEventId = event.target.dataset.id;
        this.isModalOpen = true;
    }

    closeModal() {
        this.isModalOpen = false;
    }
}
