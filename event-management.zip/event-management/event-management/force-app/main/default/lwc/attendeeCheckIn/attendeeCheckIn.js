import { LightningElement, wire, track } from 'lwc';
import getAttendees from '@salesforce/apex/AttendeeController.getAttendees';
import updateCheckInStatus from '@salesforce/apex/AttendeeController.updateCheckInStatus';

const COLUMNS = [
    { label: 'Name', fieldName: 'Name' },
    { label: 'Email', fieldName: 'Email__c' },
    { label: 'Phone', fieldName: 'Phone__c' },
    {
        type: 'button-icon',
        fixedWidth: 50,
        typeAttributes: {
            iconName: { fieldName: 'checkIcon' },
            name: 'toggle_check',
            variant: 'border-filled',
            alternativeText: 'Toggle Check-In'
        }
    }
];

export default class AttendeeCheckIn extends LightningElement {
    @track attendees;
    @track error;
    columns = COLUMNS;

    @wire(getAttendees)
    wiredAttendees({ data, error }) {
        if (data) {
            this.attendees = data.map(att => ({
                ...att,
                checkIcon: att.CheckIn_Status__c ? 'utility:check' : 'utility:close'
            }));
            this.error = undefined;
        } else if (error) {
            this.error = error.body.message;
            this.attendees = undefined;
        }
    }

    async handleRowAction(event) {
        const attendeeId = event.detail.row.Id;
        const currentStatus = event.detail.row.CheckIn_Status__c;

        try {
            await updateCheckInStatus({ attendeeId, checkedIn: !currentStatus });
            // Refresh UI
            return refreshApex(this.wiredAttendees);
        } catch (err) {
            this.error = err.body.message;
        }
    }
}
